<?php
include "header.php";


$firstNameErr = $lastNameErr = $genderErr = $hobbiesErr = "";
$firstName = $lastName = $gender = $hobbies = $message = "";
 
if(isset($_POST['firstName'])) {

    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $gender = $_POST['gender'];

    if ($firstName == "") {
        $firstNameErr =  "Please enter First Name<br />";
    }
	
	if ($lastName == "") {
        $lastNameErr =  "Please enter Last Name<br />";
    }
	
	if ($gender == "") {
    $genderErr = "Gender is required";
  }
  
    if ($hobbies == "") {
    $hobbiesErr = "Select your hobbies";
}


?>

 <form name="validationForm" action="content.php" method="post">
 <fieldset>
    <legend>Personal Details:</legend>
     
	  <div>First name:</div>
      <div><input type="text" name="firstName" value="<?= $firstName; ?>" id="fName"></div>
	  <span style="color:red;"><?= $firstNameErr; ?></span>
	  
	  <div>Last name:</div>
      <div><input type="text" name="lastName" value="<?= $lastName; ?>" id="lName"></div>
      <span style="color:red;"><?= $lastNameErr; ?></span>
     
	  <div>Gender:</div>
      <input type="radio" name="gender"  <?php if (isset($gender) && $gender == "Female") echo "checked";?> value="Female">Female
      <input type="radio" name="gender" value="<?= $gender; ?>">Male
      <input type="radio" name="gender" value="<?= $gender; ?>">Other
	 
  
      <div>Hobbies:</div>
      <div><input type="checkbox" name="hobby1">Reading Books</div>
      <div><input type="checkbox" name="hobby2">Listening Songs</div>
	  <div><input type="checkbox" name="hobby3">Playing games</div>
      <div><input type="checkbox" name="hobby4">Cooking</div>
      <div><input type="checkbox" name="hobby5">Others</div>
	  
	  <div>Message:</div>
	  <textarea name="message">Your message here....</textarea>
	  
      <div><input type="submit" value="Submit"></div>
	  
</fieldset>	  
</form>
<?php
include "footer.php";
?>