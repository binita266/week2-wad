window.onload = function(){
var f = document.forms.validationForm;
console.log(f);
f.onsubmit = validate;
function validate()
{
	console.log("tt");

    var fn = f.firstName;  
    if(fn.value==null || fn.value=="" )
    {
        alert("Enter First Name");
        return false;
    }

    var ln=f.lastName;
    if(ln.value==null || ln.value=="")
    {
        alert("Enter Last Name");
        return false;
    }
}

}