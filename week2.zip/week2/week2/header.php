<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
	<title>Lab-2</title>
	<img src="logo.png" alt="logo" height="100px" width="100px">
	<div style="float:right; color:#00001A;">Contact:Binitapatel266@gmail.com</div>
  </head>
  <body>
  