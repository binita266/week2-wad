<?php
include "header.php";
?>
<p>Thank you for submitting your form!!!</p>
<?php
include "footer.php";
?>