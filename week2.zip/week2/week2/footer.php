</body>
<footer>
  <p style="color:white; background-color:#00001A;">&copy; BINITA PATEL</p>
</footer>